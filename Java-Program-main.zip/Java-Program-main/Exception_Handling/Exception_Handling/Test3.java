import java.io.*;
public class Test3{
    public static void main(String args[]){
        PrintWriter pw=new PrintWriter("abc.txt");
        pw.println("Hello");
    }
}