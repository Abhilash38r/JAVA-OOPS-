public class Test11{
    public static void main(String args[]) throws InterruptedException{
        Thread.sleep(1000);
    }
}