public class Test8{
    public static void main(String args[]){
        System.out.println(10/0);
    
      
      throw new ArithmeticException("Division by zero is not allowed!!");
      // System.out.println("bye");
    }

}