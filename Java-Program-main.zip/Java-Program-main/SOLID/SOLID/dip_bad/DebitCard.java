package dip_bad;

public class DebitCard {
    public void doTransaction(int amount){
        System.out.println("tx done with DebitCard");
    }
}
