package isp_good;

public interface UPIPayments {
    
    public void payMoney();
    
    public void getScratchCard();
    
}