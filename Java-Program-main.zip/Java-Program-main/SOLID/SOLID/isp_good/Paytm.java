package isp_good;

public class Paytm implements UPIPayments {

    public void payMoney() {

    }

    public void getScratchCard() {

    }
}