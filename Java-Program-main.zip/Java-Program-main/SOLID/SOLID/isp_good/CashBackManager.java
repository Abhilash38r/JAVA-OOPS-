package isp_good;

public interface CashBackManager {
    
    public void getCashBackAsCreditBalance();
}