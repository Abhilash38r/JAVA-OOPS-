package isp_good;

public class PhonePe implements UPIPayments {

    public void payMoney() {

    }

    public void getScratchCard() {

    }
}