package isp_bad;

public class Paytm implements UPIPayments {

    public void payMoney() {

    }

    public void getScratchCard() {

    }
    public void getCashBackAsCreditBalance() {
        //this features is not there in Paytm
      }

}