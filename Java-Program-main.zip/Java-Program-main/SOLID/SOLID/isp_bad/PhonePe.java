package isp_bad;

public class PhonePe implements UPIPayments {

    public void payMoney() {

    }

    public void getScratchCard() {

    }
    public void getCashBackAsCreditBalance() {
        //this features is not there in Phonepe
      }

}
