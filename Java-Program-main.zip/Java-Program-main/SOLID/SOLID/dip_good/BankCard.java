package dip_good;

public interface BankCard {
    public void doTransaction(long amount);
  }
