package srp_good;

public class PrinterService {
    public void printPassbook() {
        //update transaction info in passbook
    }
    
}
