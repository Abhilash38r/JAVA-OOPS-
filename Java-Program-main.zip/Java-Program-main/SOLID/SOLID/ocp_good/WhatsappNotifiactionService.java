package ocp_good;

public class WhatsappNotifiactionService implements NotificationService{
    public void sendOTP(String medium) {
        //logic to integrate whatsapp api
    }

    public void sendTransactionReport(String medium) {
         //logic to integrate whatsapp api
    }
    
}
