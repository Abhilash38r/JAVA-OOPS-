package lsp_good;

public interface SocialMedia {

    public   void chatWithFriend();

    public   void sendPhotosAndVideos();

}