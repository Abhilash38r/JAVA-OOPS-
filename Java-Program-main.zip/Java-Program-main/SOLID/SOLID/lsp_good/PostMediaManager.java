package lsp_good;

public interface PostMediaManager {

    public  void publishPost(Object post);
}