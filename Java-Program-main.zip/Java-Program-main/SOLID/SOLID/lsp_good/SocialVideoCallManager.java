package lsp_good;

public interface SocialVideoCallManager {
    public void groupVideoCall(String... users);
}