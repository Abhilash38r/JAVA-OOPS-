import java.util.LinkedList;
import java.util.List;


public class LinkedListConstructorDemo {
    public static void main(String[] args) {
        LinkedList<String> issuedBooks = new LinkedList<>();
        issuedBooks.add(e)
    }
}
