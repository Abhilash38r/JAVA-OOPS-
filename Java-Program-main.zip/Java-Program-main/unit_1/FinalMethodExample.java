class Employee{
    String name;
    double salary;

    Employee(String name,double salary){
        this.name=name;
        this.salary=salary;
    }

    public final void calculateBonus(){
        double bonus = salary * 
    }
}


class Manager extends Employee {

    public void 
}
public class FinalMethodExample {
    
}
