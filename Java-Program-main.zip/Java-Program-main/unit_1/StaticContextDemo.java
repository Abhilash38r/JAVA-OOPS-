public class StaticContextDemo {
    int rollNo=101;
    static String school="ABC";
    public static void main(String[] args) {
        
    }
}
