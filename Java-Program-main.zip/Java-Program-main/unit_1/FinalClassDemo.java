final class HRDepartment{
    private final String policy = "No employee cant";
    public void showpolicy(){
        
    }
}


public class FinalClassDemo {
    
}
