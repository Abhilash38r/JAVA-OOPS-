import java.util.*;

public class add{
    public static void main(String[] args) {
        int a, b;
        Scanner abc=new Scanner(System.in);
        System.out.println("Enter radius of circle");
        a=abc.nextInt();
        b=abc.nextInt();
        System.out.println("Area of circle = "+(a+b));
    }
}