public class abstraction {
    public static void main(String[] args) {
        
    }

}

abstract  class Animal{
    abstract  void walk();

    void eats(){
        System.out.println("Eats anything");
    }

}

