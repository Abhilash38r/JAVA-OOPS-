public class Empl {
    
}

class Employee{
    String name;
    int id;

    static class Company{
        String companyName;
        String location;

        public Company() {
        }

        
    }
}
