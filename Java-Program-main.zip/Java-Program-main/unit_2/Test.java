public  class Test {
    public static void doStuff(){

    }
    public static void doMoreStuff(){
        System.out.println(10/0);
    } 
}
