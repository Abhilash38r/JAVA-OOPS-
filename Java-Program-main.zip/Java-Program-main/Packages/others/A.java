package others;

public class A {
    public void show(){
System.out.println("hi");
    }
}
