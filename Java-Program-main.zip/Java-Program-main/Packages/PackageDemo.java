// import tools.AdvanceCalculator;
// import tools.AdvanceCalculator;
import others.A;
import others.tools.AdvanceCalculator;
import others.tools.Calculator;
//import others.*
public class PackageDemo {
    public static void main(String[] args) {
        // AdvanceCalculator cal = new AdvanceCalculator();

        A a = new A();
        AdvanceCalculator calc1= new AdvanceCalculator();
        Calculator cal = new Calculator();
    }
}
